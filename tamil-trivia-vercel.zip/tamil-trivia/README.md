# Tamil Trivia — Cinema & Music Quiz

A responsive React + Vite quiz app featuring 10 Tamil movie and music questions.
It runs entirely in the browser: no backend or environment variables are required.

## Run locally

1. Install Node.js (LTS).
2. Open this project folder in a terminal.
3. Run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL printed by Vite.

## Run the tests

```bash
npm test
```

## Build for production

```bash
npm run build
npm run preview
```

Vite creates the production site in `dist/`.

## Push to GitHub

Create an empty repository on GitHub, then run these commands from this folder:

```bash
git init
git add .
git commit -m "Create Tamil Trivia quiz website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own GitHub repository URL.

## Deploy on Vercel

1. Sign in to Vercel and choose **Add New → Project**.
2. Import the GitHub repository you just created.
3. Vercel should detect Vite automatically.
4. Confirm **Build Command** is `npm run build`.
5. Confirm **Output Directory** is `dist`.
6. Select **Deploy**.

The included `vercel.json` keeps client-side routing compatible with Vercel.

## How scoring works

- Each correct answer earns **100 base points**.
- A speed bonus is added based on how quickly the question is answered (up to **50 bonus points**).
- Incorrect answers earn **0 points**.
- Final ranking is ordered by:
  1. Total points (highest first)
  2. Correct answers (highest first)
  3. Completion time (lowest first)
  4. Earlier completion timestamp as a final tie-breaker

Leaderboard entries are stored in that browser's `localStorage`. Since this version has no database, each browser/device has its own leaderboard. To share one leaderboard across all players, connect a database such as Supabase or Firebase in a future version.
