import test from "node:test";
import assert from "node:assert/strict";
import {
  calculateQuestionPoints,
  createResult,
  sortLeaderboard,
  saveResult,
  LEADERBOARD_KEY
} from "../src/quizLogic.js";

function memoryStorage() {
  const data = new Map();
  return {
    getItem(key) { return data.has(key) ? data.get(key) : null; },
    setItem(key, value) { data.set(key, value); }
  };
}

test("correct answers earn base points plus a speed bonus", () => {
  assert.equal(calculateQuestionPoints(true, 0), 150);
  assert.equal(calculateQuestionPoints(true, 10), 125);
  assert.equal(calculateQuestionPoints(true, 20), 100);
});

test("incorrect answers earn no points regardless of speed", () => {
  assert.equal(calculateQuestionPoints(false, 0), 0);
  assert.equal(calculateQuestionPoints(false, 18), 0);
});

test("question points clamp elapsed time to the timer range", () => {
  assert.equal(calculateQuestionPoints(true, -5), 150);
  assert.equal(calculateQuestionPoints(true, 25), 100);
});

test("result counts correct answers and sums points", () => {
  const result = createResult({
    username: "  MusicFan  ",
    answers: [{ isCorrect: true, points: 125 }, { isCorrect: false, points: 0 }, { isCorrect: true, points: 140 }],
    elapsedSeconds: 42,
    completedAt: 1000
  });
  assert.equal(result.username, "MusicFan");
  assert.equal(result.correct, 2);
  assert.equal(result.score, 265);
  assert.equal(result.total, 3);
  assert.equal(result.elapsedSeconds, 42);
});

test("leaderboard sorts by score, then correct answers, then faster time", () => {
  const sorted = sortLeaderboard([
    { id: "slow", score: 200, correct: 2, elapsedSeconds: 70, completedAt: 1 },
    { id: "accurate", score: 200, correct: 3, elapsedSeconds: 80, completedAt: 2 },
    { id: "fast", score: 200, correct: 3, elapsedSeconds: 55, completedAt: 3 },
    { id: "top", score: 250, correct: 2, elapsedSeconds: 90, completedAt: 4 }
  ]);
  assert.deepEqual(sorted.map((entry) => entry.id), ["top", "fast", "accurate", "slow"]);
});

test("saving a result persists a sorted leaderboard and keeps at most 50 entries", () => {
  const storage = memoryStorage();
  const result = { id: "new", username: "New", score: 300, correct: 3, elapsedSeconds: 30, completedAt: 10 };
  const saved = saveResult(result, storage);
  assert.equal(saved[0].id, "new");
  assert.deepEqual(JSON.parse(storage.getItem(LEADERBOARD_KEY)).map((entry) => entry.id), ["new"]);
});
