export const quizQuestions = [
  {
    id: 1,
    category: "Tamil Cinema",
    question: "Which film marked the directorial debut of Lokesh Kanagaraj?",
    options: ["Maanagaram", "Kaithi", "Master", "Vikram"],
    answer: "Maanagaram",
    fact: "Maanagaram (2017) was Lokesh Kanagaraj's first feature film as a director."
  },
  {
    id: 2,
    category: "Tamil Music",
    question: "Who composed the music for the film Roja?",
    options: ["Harris Jayaraj", "A. R. Rahman", "Ilaiyaraaja", "Deva"],
    answer: "A. R. Rahman",
    fact: "Roja introduced A. R. Rahman as a film composer in 1992."
  },
  {
    id: 3,
    category: "Tamil Cinema",
    question: "In which film does the character Senapathy appear?",
    options: ["Gentleman", "Indian", "Mudhalvan", "Anniyan"],
    answer: "Indian",
    fact: "Senapathy is the central character played by Kamal Haasan in Shankar's Indian."
  },
  {
    id: 4,
    category: "Tamil Music",
    question: "Which singer is popularly known as the 'Nightingale of South India'?",
    options: ["K. S. Chithra", "S. Janaki", "P. Susheela", "Swarnalatha"],
    answer: "K. S. Chithra",
    fact: "K. S. Chithra is widely celebrated for her work across South Indian languages."
  },
  {
    id: 5,
    category: "Tamil Cinema",
    question: "Who directed the 1996 film Kadhal Desam?",
    options: ["Shankar", "Kathir", "Bala", "Gautham Vasudev Menon"],
    answer: "Kathir",
    fact: "Kadhal Desam was written and directed by Kathir."
  },
  {
    id: 6,
    category: "Tamil Music",
    question: "Which composer created the soundtrack for the film 96?",
    options: ["Govind Vasantha", "Santhosh Narayanan", "Sean Roldan", "Anirudh Ravichander"],
    answer: "Govind Vasantha",
    fact: "Govind Vasantha composed the music for C. Prem Kumar's 96."
  },
  {
    id: 7,
    category: "Tamil Cinema",
    question: "Which actor played the lead role of Sakthi in Ghilli?",
    options: ["Ajith Kumar", "Vijay", "Suriya", "Dhanush"],
    answer: "Vijay",
    fact: "Vijay played Velu, also known as Ghilli, in the 2004 action film."
  },
  {
    id: 8,
    category: "Tamil Music",
    question: "Who sang the song 'Why This Kolaveri Di' with Dhanush?",
    options: ["Anirudh Ravichander", "Yuvan Shankar Raja", "G. V. Prakash Kumar", "Vijay Antony"],
    answer: "Dhanush",
    fact: "Dhanush performed the song, which was composed by Anirudh Ravichander for 3."
  },
  {
    id: 9,
    category: "Tamil Cinema",
    question: "Which film features the characters Ram and Jaanu?",
    options: ["Autograph", "Alaipayuthey", "96", "Vinnaithaandi Varuvaayaa"],
    answer: "96",
    fact: "Vijay Sethupathi and Trisha play Ram and Jaanu in the film 96."
  },
  {
    id: 10,
    category: "Tamil Music",
    question: "Who composed the song 'Aaluma Doluma' from Vedalam?",
    options: ["Anirudh Ravichander", "D. Imman", "Harris Jayaraj", "Yuvan Shankar Raja"],
    answer: "Anirudh Ravichander",
    fact: "Anirudh Ravichander composed the soundtrack for Vedalam."
  }
];
