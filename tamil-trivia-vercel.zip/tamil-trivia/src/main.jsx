import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { quizQuestions } from "./quizData";
import {
  calculateQuestionPoints,
  createResult,
  readLeaderboard,
  saveResult
} from "./quizLogic";
import "./styles.css";

const QUESTION_SECONDS = 20;

function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

function App() {
  const [screen, setScreen] = useState("welcome");
  const [username, setUsername] = useState("");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selected, setSelected] = useState("");
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(QUESTION_SECONDS);
  const [questionStartedAt, setQuestionStartedAt] = useState(Date.now());
  const [quizStartedAt, setQuizStartedAt] = useState(0);
  const [leaderboard, setLeaderboard] = useState(() => readLeaderboard());
  const [latestResult, setLatestResult] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const currentQuestion = quizQuestions[questionIndex];
  const progress = ((questionIndex + (showFeedback ? 1 : 0)) / quizQuestions.length) * 100;

  useEffect(() => {
    if (screen !== "quiz" || showFeedback) return undefined;
    const timer = window.setInterval(() => {
      setTimeLeft((remaining) => {
        if (remaining <= 1) {
          window.clearInterval(timer);
          return 0;
        }
        return remaining - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [screen, questionIndex, showFeedback]);

  useEffect(() => {
    if (screen === "quiz" && timeLeft === 0 && !showFeedback) {
      submitAnswer("");
    }
  }, [timeLeft, screen, showFeedback]);

  function startQuiz(event) {
    event.preventDefault();
    const cleanName = username.trim();
    if (!cleanName) return;
    setUsername(cleanName.slice(0, 18));
    setQuestionIndex(0);
    setAnswers([]);
    setSelected("");
    setTimeLeft(QUESTION_SECONDS);
    setQuestionStartedAt(Date.now());
    setQuizStartedAt(Date.now());
    setShowFeedback(false);
    setScreen("quiz");
  }

  function submitAnswer(choice) {
    if (showFeedback) return;
    setSelected(choice);
    const elapsed = Math.min(QUESTION_SECONDS, (Date.now() - questionStartedAt) / 1000);
    const isCorrect = choice === currentQuestion.answer;
    const points = calculateQuestionPoints(isCorrect, elapsed, QUESTION_SECONDS);
    const answer = {
      questionId: currentQuestion.id,
      choice,
      isCorrect,
      points,
      elapsedSeconds: elapsed
    };
    setAnswers((previous) => [...previous, answer]);
    setShowFeedback(true);
  }

  function nextQuestion() {
    if (questionIndex === quizQuestions.length - 1) {
      const finalAnswers = answers;
      const result = createResult({
        username,
        answers: finalAnswers,
        elapsedSeconds: Math.round((Date.now() - quizStartedAt) / 1000)
      });
      setLatestResult(result);
      setLeaderboard(saveResult(result));
      setScreen("results");
      return;
    }
    setQuestionIndex((index) => index + 1);
    setSelected("");
    setTimeLeft(QUESTION_SECONDS);
    setQuestionStartedAt(Date.now());
    setShowFeedback(false);
  }

  function replay() {
    setQuestionIndex(0);
    setAnswers([]);
    setSelected("");
    setLatestResult(null);
    setTimeLeft(QUESTION_SECONDS);
    setQuestionStartedAt(Date.now());
    setQuizStartedAt(Date.now());
    setShowFeedback(false);
    setScreen("quiz");
  }

  const correctCount = answers.filter((answer) => answer.isCorrect).length;
  const currentPoints = answers.reduce((sum, answer) => sum + answer.points, 0);
  const resultMessage = latestResult?.correct === 10
    ? "Perfect score. You know your Tamil pop culture."
    : latestResult?.correct >= 7
      ? "Excellent run. Your Tamil trivia game is strong."
      : latestResult?.correct >= 4
        ? "Good effort. There is more cinema history to discover."
        : "Every fan starts somewhere. Give it another round.";

  const rank = useMemo(() => {
    if (!latestResult) return 0;
    return leaderboard.findIndex((entry) => entry.id === latestResult.id) + 1;
  }, [leaderboard, latestResult]);

  return (
    <main className="app-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar">
        <button className="brand" onClick={() => setScreen("welcome")} aria-label="Tamil Trivia home">
          <span className="brand-mark">T<span>✳</span></span>
          <span className="brand-name">TAMIL<span>TRIVIA</span></span>
        </button>
        <div className="topbar-right">
          <span className="edition">CINEMA / MUSIC EDITION</span>
          <span className="live-dot" aria-hidden="true" />
        </div>
      </header>

      {screen === "welcome" && (
        <section className="welcome-layout">
          <div className="welcome-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> THE ULTIMATE FAN CHECK</div>
            <h1>How well do<br />you know <em>Tamil</em><br />pop culture?</h1>
            <p className="hero-description">From iconic frames to unforgettable melodies. Ten questions stand between you and the leaderboard.</p>
            <div className="hero-meta">
              <div><strong>10</strong><span>QUESTIONS</span></div>
              <div><strong>20s</strong><span>PER QUESTION</span></div>
              <div><strong>∞</strong><span>BRAGGING RIGHTS</span></div>
            </div>
          </div>
          <div className="welcome-panel">
            <div className="panel-topline"><span>01 / PLAYER ENTRY</span><span>READY?</span></div>
            <div className="entry-symbol" aria-hidden="true">T<span>✳</span></div>
            <h2>Take your<br /><em>place.</em></h2>
            <p className="panel-description">Enter a name. Trust your instincts. Make every second count.</p>
            <form onSubmit={startQuiz} className="entry-form">
              <label htmlFor="username">YOUR PLAYER NAME</label>
              <input
                id="username"
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                placeholder="e.g. ThalapathyFan"
                maxLength={18}
                autoComplete="nickname"
                required
              />
              <button className="primary-button" type="submit">
                START THE QUIZ <span aria-hidden="true">↗</span>
              </button>
            </form>
            <div className="panel-foot"><span>NO SIGN-UP REQUIRED</span><span>10 ROUNDS · 1 CHAMPION</span></div>
          </div>
          <div className="welcome-bottom"><span>MADE FOR THE FANS</span><span>01 — 10</span></div>
        </section>
      )}

      {screen === "quiz" && currentQuestion && (
        <section className="quiz-layout">
          <div className="quiz-heading">
            <div>
              <div className="eyebrow"><span className="eyebrow-line" /> THE FAN CHECK IS ON</div>
              <h1>Trust your <em>memory.</em></h1>
            </div>
            <div className="player-chip"><span className="player-avatar">{username.charAt(0).toUpperCase()}</span><span>{username}</span></div>
          </div>
          <div className="quiz-stats">
            <div className="stat-block"><span>ROUND</span><strong>{String(questionIndex + 1).padStart(2, "0")}<small> / 10</small></strong></div>
            <div className="stat-block"><span>YOUR SCORE</span><strong>{currentPoints.toLocaleString("en-IN")}<small> PTS</small></strong></div>
            <div className={`timer-block ${timeLeft <= 5 ? "urgent" : ""}`}><span>TIME LEFT</span><strong>00:{String(timeLeft).padStart(2, "0")}</strong></div>
          </div>
          <div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div>
          <article className="question-card">
            <div className="question-card-top"><span>{currentQuestion.category.toUpperCase()}</span><span>QUESTION {String(questionIndex + 1).padStart(2, "0")}</span></div>
            <h2>{currentQuestion.question}</h2>
            <div className="answer-grid">
              {currentQuestion.options.map((option, index) => {
                const isAnswer = option === currentQuestion.answer;
                const isChosen = selected === option;
                let stateClass = "";
                if (showFeedback && isAnswer) stateClass = "is-correct";
                else if (showFeedback && isChosen && !isAnswer) stateClass = "is-wrong";
                return (
                  <button
                    key={option}
                    className={`answer-option ${stateClass} ${isChosen ? "is-selected" : ""}`}
                    onClick={() => submitAnswer(option)}
                    disabled={showFeedback}
                  >
                    <span className="option-letter">{String.fromCharCode(65 + index)}</span>
                    <span>{option}</span>
                    {showFeedback && isAnswer && <span className="option-mark">✓</span>}
                    {showFeedback && isChosen && !isAnswer && <span className="option-mark">×</span>}
                  </button>
                );
              })}
            </div>
            {showFeedback && (
              <div className={`feedback ${selected === currentQuestion.answer ? "feedback-good" : "feedback-bad"}`}>
                <div><strong>{selected === currentQuestion.answer ? "YOU GOT IT" : selected ? "NOT QUITE" : "TIME'S UP"}</strong><p>{currentQuestion.fact}</p></div>
                <button className="next-button" onClick={nextQuestion}>
                  {questionIndex === quizQuestions.length - 1 ? "SEE MY RESULTS" : "NEXT QUESTION"} <span>→</span>
                </button>
              </div>
            )}
          </article>
          <div className="quiz-footer"><span>FAST ANSWERS EARN UP TO 50 BONUS POINTS</span><span>{correctCount} CORRECT SO FAR</span></div>
        </section>
      )}

      {screen === "results" && latestResult && (
        <section className="results-layout">
          <div className="results-main">
            <div className="eyebrow"><span className="eyebrow-line" /> ROUND COMPLETE</div>
            <div className="result-kicker">THE FINAL CUT</div>
            <h1>{latestResult.correct === 10 ? "Iconic." : "That’s a wrap,"}<br /><em>{username}.</em></h1>
            <p className="hero-description">{resultMessage}</p>
            <div className="score-display"><strong>{latestResult.score.toLocaleString("en-IN")}</strong><span>POINTS</span></div>
            <div className="result-metrics">
              <div><strong>{latestResult.correct}<small>/10</small></strong><span>CORRECT</span></div>
              <div><strong>{formatTime(latestResult.elapsedSeconds)}</strong><span>TIME TAKEN</span></div>
              <div><strong>#{rank || "—"}</strong><span>LEADERBOARD</span></div>
            </div>
            <button className="primary-button replay-button" onClick={replay}>PLAY AGAIN <span>↗</span></button>
          </div>
          <aside className="leaderboard-panel">
            <div className="leaderboard-header"><div><div className="eyebrow">THE HALL OF FAME</div><h2>Leaderboard<span>.</span></h2></div><span className="trophy-mark">✳</span></div>
            <div className="leaderboard-columns"><span>RANK / PLAYER</span><span>SCORE</span></div>
            <div className="leaderboard-list">
              {leaderboard.length === 0 && <p className="empty-state">No scores yet. Be the first to play.</p>}
              {leaderboard.slice(0, 10).map((entry, index) => (
                <div className={`leader-row ${entry.id === latestResult.id ? "leader-row-current" : ""}`} key={entry.id}>
                  <div className="leader-person"><span className="leader-rank">{String(index + 1).padStart(2, "0")}</span><span className="leader-avatar">{entry.username.charAt(0).toUpperCase()}</span><div><strong>{entry.username}</strong><small>{entry.correct}/10 CORRECT · {formatTime(entry.elapsedSeconds)}</small></div></div>
                  <strong className="leader-score">{entry.score.toLocaleString("en-IN")}</strong>
                </div>
              ))}
            </div>
            <div className="leaderboard-note">RANKED BY SCORE, ACCURACY & SPEED</div>
          </aside>
        </section>
      )}

      <footer className="site-footer"><span>© 2026 TAMIL TRIVIA</span><span>CELEBRATING THE SOUND & STORY OF TAMIL CINEMA</span><span>BUILT FOR THE CULTURE.</span></footer>
    </main>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode><App /></React.StrictMode>
);
