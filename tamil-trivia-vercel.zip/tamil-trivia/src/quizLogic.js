export const LEADERBOARD_KEY = "tamil-trivia-leaderboard-v1";

export function calculateQuestionPoints(isCorrect, elapsedSeconds, limitSeconds = 20) {
  if (!isCorrect) return 0;
  const safeElapsed = Math.max(0, Number(elapsedSeconds) || 0);
  const remainingRatio = Math.max(0, Math.min(1, (limitSeconds - safeElapsed) / limitSeconds));
  const speedBonus = Math.round(remainingRatio * 50);
  return 100 + speedBonus;
}

export function createResult({ username, answers, elapsedSeconds, completedAt = Date.now() }) {
  const correct = answers.filter((answer) => answer.isCorrect).length;
  const score = answers.reduce((total, answer) => total + answer.points, 0);

  return {
    id: `${completedAt}-${Math.random().toString(36).slice(2, 9)}`,
    username: username.trim(),
    score,
    correct,
    total: answers.length,
    elapsedSeconds: Math.max(0, Number(elapsedSeconds) || 0),
    completedAt
  };
}

export function sortLeaderboard(entries) {
  return [...entries].sort((a, b) =>
    b.score - a.score ||
    b.correct - a.correct ||
    a.elapsedSeconds - b.elapsedSeconds ||
    a.completedAt - b.completedAt
  );
}

export function readLeaderboard(storage = globalThis.localStorage) {
  try {
    const parsed = JSON.parse(storage.getItem(LEADERBOARD_KEY) || "[]");
    return Array.isArray(parsed) ? sortLeaderboard(parsed) : [];
  } catch {
    return [];
  }
}

export function saveResult(result, storage = globalThis.localStorage) {
  const current = readLeaderboard(storage);
  const updated = sortLeaderboard([result, ...current]).slice(0, 50);
  storage.setItem(LEADERBOARD_KEY, JSON.stringify(updated));
  return updated;
}
